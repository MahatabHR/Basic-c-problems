#include <bits/stdc++.h>
using namespace std;

  void greet(string name,int age)
{
   cout << "welcome " << name << " you are " << age << " years old.Congratulations for surviving this long." << endl;
}
int main()
{
    string name;
    int age;
    cout << "Enter your age:";
    cin >> age;
    cout << "Enter your name:";
    cin >> name;
    greet(name,age);

    return 0;
}
