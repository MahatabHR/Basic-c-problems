#include <bits/stdc++.h>
using namespace std;
double area(float base,float height)
{
    cout << "Area of rectangle:" << (base * height)/2 << endl;
}
int main()
{
    float base;
    float height;
    cout << "Enter the amount of base:";
    cin >>  base;
    cout << "Enter the amount of height:";
    cin >> height;
    area(base,height);

    return 0;
}

