#include<bits/stdc++.h>
using namespace std;
int main()
{
 int a,b,c;

 cout << "Enter the weight of package(in Kg):";
 cin >> a;
 cout << "Enter the distance of destination(in meter):";
 cin >> b;

 if(a<=5)
 {
    cout << "Shipping cost :" << (b/a) * 0.5 << endl;
 }
 else if(5<a<20)
 {
    cout << "Shipping cost:" << (b/a) * 1 <<  endl;
 }
 else if(20<a)
 {
    cout << "Shipping cost:" << (b/a) * 2 << endl;
 }

return 0;
}
