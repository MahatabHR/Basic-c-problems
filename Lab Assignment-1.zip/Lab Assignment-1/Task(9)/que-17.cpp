#include <bits/stdc++.h>
using namespace std;

int main()
{
    float height;
    int age;
    cout << "To enter the roller coaster you need some requirements";
    cout << "\nEnter your height:";
    cin >> height;
    cout << "Enter your age:";
    cin >> age;
    if(age>16 && height >= 5)
    {
        cout << "Enter the roller coster.";
    }
    else
    {
        cout << "you are not allowed.";
    }
    return 0;

}



