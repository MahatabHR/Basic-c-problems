
#include <bits/stdc++.h>
using namespace std;

int main()
{
    bool isStudent = true;
    int studentId = 189;

    cout << "Student:" << isStudent << "\n Student Id:" << studentId << endl;
    return 0;
}
