#include <bits/stdc++.h>
using namespace std;

int main()
{
    int height = 5;
    double weight = 53.5;
    string eye_color = "dark brown";
    cout << "Height(feet):" << height << "\nWeight:"<< weight << "\nEye color:" << eye_color <<endl;
}
