#include <bits/stdc++.h>
using namespace std;

int commonRecursive(int n,int m,int a)
{
    if (n%2 == m%2)
        return a;
}
int main()
{
    int n,m,a;
    cout << "Enter two integer numbers:";
    c
}
