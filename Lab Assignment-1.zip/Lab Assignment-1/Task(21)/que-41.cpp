#include <bits/stdc++.h>
using namespace std;
int sumRecursive(int n)
{
    if(n==0)
        return 0;
    else
        {

        return n + sumRecursive(n-1);
        }

}
int main()
{
    int n;
    cout << "Enter the number for recursion:";
    cin >> n;
    if(n<0)
            {
            cout << "Enter a positive integer.";
            }
    else    {
    cout << "Sum of the numbers till " << n << " is: " << sumRecursive(n)<< endl;
            }
    return 0;
}
