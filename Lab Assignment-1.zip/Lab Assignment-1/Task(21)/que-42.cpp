#include <bits/stdc++.h>
using namespace std;

int commonRecursive(int n,int m)
{
    if (m==0)
        return n;
        else
        {
            return commonRecursive(m,n%m);
        }
}
int main()
{
    int n,m;
    cout << "Enter two integer numbers:\n";
    cin>>n>>m;
    cout << "Greatest Common Divisor: " << commonRecursive(n,m) << endl;
    return 0;

}

