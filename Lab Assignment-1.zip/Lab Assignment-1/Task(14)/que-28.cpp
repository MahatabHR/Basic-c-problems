
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int i;
    int numbers[10];
    for(i=1;i<21;i++)
    {
            if(i%2 == 0)
            cout << i << endl;
    }
}
