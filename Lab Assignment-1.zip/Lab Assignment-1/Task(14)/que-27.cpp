#include <bits/stdc++.h>
using namespace std;

int main()
{
    int i;
    float numbers[5] = {10.5,12.2,13.3,14.3,14.5};
    cout << "Numbers in the arrays are:\n";
    for(i=0;i<5;i++)
    {
        cout << numbers[i] << endl;
    }
}

