#include <bits/stdc++.h>
using namespace std;

int main() {
    cout << "Learning C++ is fun!" << endl;
    return 0;
}

