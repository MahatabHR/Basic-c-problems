#include <bits/stdc++.h>
using namespace std;

int main() {
    cout << "Mahatab starts coding in C++!" << endl;
    return 0;
}

