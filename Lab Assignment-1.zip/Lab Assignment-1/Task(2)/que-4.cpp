#include <bits/stdc++.h>
using namespace std;
int main()
{
    string firstName = "Mahatb";
    string lastName = "Rakib";
    cout << "Full name is :" << firstName + lastName << endl;
}
