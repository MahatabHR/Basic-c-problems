#include <bits/stdc++.h>
using namespace std;

int main() {
    cout << "The result of 12 * 4 is: " << 12 * 4 << endl;
    cout << "The result of 12 / 4 is: " << 12 / 4 << endl;
    return 0;
}


