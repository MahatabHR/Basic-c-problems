#include <bits/stdc++.h>
using namespace std;

int main()
{
 int i;

 cout << "Square of numbers from 1 to 5:\n";
 for(i=1;i<6;i++)
  {
   cout << i * i << endl;
  }

 return 0;

}

