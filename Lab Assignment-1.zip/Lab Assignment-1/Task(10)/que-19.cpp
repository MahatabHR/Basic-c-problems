#include <bits/stdc++.h>
using namespace std;

int main()
{
 int i;
 cout << "First 10 multiplication of 3:\n";
 for(i=1;i<11;i++)
 {
     cout <<  i * 3 << endl;
 }
 return 0;

}
