#include <bits/stdc++.h>
using namespace std;

int main()
{
    int a = 10;
    float b = 20;
    char c = 'X';
    int *ptr = &a;
    float *ptr1 = &b;
    char *ptr2 = &c;
    cout << "Integer value position:" << ptr << endl;
    cout << "float value position:" << ptr1 << endl;
    cout << "Charachter value position:" << ptr2 << endl;
    return 0;

}


