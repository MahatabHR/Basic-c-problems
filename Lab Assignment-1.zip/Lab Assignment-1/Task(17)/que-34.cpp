#include <iostream>
using namespace std;

int main() {
    int arr[5] = {11,12,13,14,15 };
    int *pointArr = arr;
    for (int i = 0; i < 5; i++) {
        cout << *(pointArr + i) << endl;
    }
    return 0;
}
