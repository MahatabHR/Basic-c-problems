#include <bits/stdc++.h>
using namespace std;

int main()
{
    int length;
    int width;
    int are;

    cout << "Enter your length:";
    cin >> length;

    cout<< "Enter your width:";
    cin>> width;

    cout << "The area of the rectangle:" << length * width << endl; /*The formula for the area of a rectangle is: Area= Length * Width ; where are is the total space covered by the rectangle and
                                                                      length is the Length of rectangle and width is the Width of rectangle.*/
    return 0;
}


