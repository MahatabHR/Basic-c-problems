#include <bits/stdc++.h>
using namespace std;

int main()
{
    int firstNumber = 12, secondNumber = 8; //declaration of variables with value
    cout << "sum of the number's = " << firstNumber + secondNumber << endl; //prints the output by summing the number values

    return 0;
}

