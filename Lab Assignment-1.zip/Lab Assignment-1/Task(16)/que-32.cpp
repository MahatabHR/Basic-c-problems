#include <bits/stdc++.h>
using namespace std;

struct Point
{
  int x;
  int y;
};
int main ()
{
    Point point1 = {2,6};
    Point point2 = {4,8};
    cout << "(" << point1.x << "," << point1.y<< ")" << endl;
    cout << "(" << point2.x << "," << point2.y <<")" << endl;
    return 0;
}


