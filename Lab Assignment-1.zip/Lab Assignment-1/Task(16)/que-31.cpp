#include <bits/stdc++.h>
using namespace std;

struct Rectangle
{
  int width;
  int height;
};
int main ()
{
    Rectangle rectangle1 = {40,60};
    cout << "Rectangle width is:" << rectangle1.width << "\nRectangle height is:" << rectangle1.height << endl;
    return 0;
}

