#include <bits/stdc++.h>
using namespace std;

class circle
{
private:
    double radius;

public:
    void setRadius(double r)
    {
        if(r>=0)
        {
            radius = r;
        }

        else
        {
            cout << "Radius invalid.";
            radius = 0;
        }
    }



double calculateArea()
{
    return 3.14 * radius * radius;
}
};


int main()
{
    circle myCircle;


    myCircle.setRadius(5.0);
    cout << "The area of the circle is:" << myCircle.calculateArea() << endl;
    return 0;
}




