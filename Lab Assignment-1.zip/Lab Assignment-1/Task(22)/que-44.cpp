#include <bits/stdc++.h>
using namespace std;

class Student
{
private:
    string name;
    int age;
    double GPA;

public:
    Student(string n,int a,double g) : name(n),age(a),GPA(g) {}
void printDetails()
{
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "GPA: " << GPA << endl;
}
};


int main(){

    Student student1("Mahatab",21,5.00);
    student1.printDetails();

    return 0;



}
