#include <bits/stdc++.h>
using namespace std;

int main()
{
 int i;
 for(i=1;i<11;i++)
     {

     cout << i << endl;
     if(i==6)
     {
       break;
     }
     }
}
