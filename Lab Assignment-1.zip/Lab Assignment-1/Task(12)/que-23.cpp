#include <bits/stdc++.h>
using namespace std;

int main()
{
 int a;
 cout << "Enter a number:";
 cin >> a;
 while(a!= (-1))
 {
     cout << "Enter a number again:";
     cin >> a;
     if(a==(-1))
     {
         break;
     }
 }
 cout << "Process ended.";
 return 0;
}
