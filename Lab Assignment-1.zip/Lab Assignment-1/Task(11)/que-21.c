#include <bits/stdc++.h>
using namespace std;

float main()
{
 int n;
 float i;
 cout << "Enter the number to calculate factorial:";
 cin >> n;
 while(i=n(n-1))
 {
     i=0;
     i++;
 }
 cout << i << endl;
}

