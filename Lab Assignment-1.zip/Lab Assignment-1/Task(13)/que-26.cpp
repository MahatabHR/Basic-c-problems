#include <bits/stdc++.h>
using namespace std;

int main() {
    int i = 0;
    while (i < 10) {
        i++;
        if (i % 5 == 0) continue;
        cout <<  i << endl;
    }
    cout << "Skipped numbers that are divisible with 5.";
    return 0;
}

