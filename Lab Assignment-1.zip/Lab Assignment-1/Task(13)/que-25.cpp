#include <bits/stdc++.h>
using namespace std;

int main()
{
 int i;
 for(i=1;i<11;i++)
    {
     if(i != 4 && i != 7)
     cout << i << endl;

     }
}
