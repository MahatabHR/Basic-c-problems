#include <iostream>
using namespace std;

int main() {
    char arr[10] = "Hello";
    arr[0] = 'h';
    cout << arr << endl;
    return 0;
}
