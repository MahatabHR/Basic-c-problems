#include <bits/stdc++.h>
using namespace std;

int multiply(int a,int b)
{
    return a * b ;
}

double multiply(double c,double d)
{
    return c * d ;
}

int main()
{
    int a,b;
    double c,d;
    cout << "Enter 1st integer number:";
    cin >>a;
    cout << "Enter 2nd integer number:";
    cin >>b;
    cout << "Enter 1st double number:";
    cin >> c;
    cout << "Enter 2nd double number:";
    cin >> d;
    cout << "Multiplication of integers:" << multiply(a,b) << endl;
    cout << "Multiplication of double:" << multiply(c,d) << endl;
    return 0;
}




