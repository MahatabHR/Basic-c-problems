#include <bits/stdc++.h>
using namespace std;

double area(double a,double b)
{
    return a * b ;
}

double area(double c)
{
    return 3.14 * c * c;
}

int main()
{
    double a,b;
    double c;
    cout << "Enter height of rectangle:";
    cin >>a;

    cout << "Enter width of rectangle:";
    cin >>b;

    cout << "Enter radius of circle:";
    cin >> c;

    cout << "Area of Rectangle:" << area(a,b) << endl;

    cout << "Area of Circle:" << area(c) << endl;
    return 0;
}




