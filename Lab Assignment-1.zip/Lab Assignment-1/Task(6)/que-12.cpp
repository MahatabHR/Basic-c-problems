#include <bits/stdc++.h>
using namespace std;

int main()
{
    int num = 10;
    cout << "Main number:" << num << endl;
    num++;
    cout << "After incrementing:" << num << endl;
    num--;
    cout << "After decrementing:" << num << endl;
    num++;
    cout << "Again incrementing:" << num << endl;
    return 0;
}
