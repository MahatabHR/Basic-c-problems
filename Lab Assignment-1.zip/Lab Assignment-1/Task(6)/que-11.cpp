#include <bits/stdc++.h>
using namespace std;

int main()
{
  int firstNumber = 15;
  int secondNumber = 4;
  int remainder = firstNumber % secondNumber;

  cout << "Remainder:" << remainder << endl;
  return 0;
}
