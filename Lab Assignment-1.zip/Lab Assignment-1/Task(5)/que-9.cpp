#include <bits/stdc++.h>
using namespace std;

int main()
{
    float number = 10.5;
    int integerpart = (int)number;
    cout << "Number:" << number << endl;
    cout << "Integer part :" << integerpart << endl;
    return 0;
}
