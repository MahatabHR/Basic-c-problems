#include <bits/stdc++.h>
using namespace std;

int main()
{
    double number = 10.223;
    int integerpart = (int)number;
    cout << "Number:" << number << endl;
    cout << "Integer Number:" << integerpart << endl;
    return 0;

}
