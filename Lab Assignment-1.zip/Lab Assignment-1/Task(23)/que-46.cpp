#include<bits/stdc++.h>
using namespace std;

int main() {

    std::ofstream outputFile("squares.txt");


    if (!outputFile.is_open()) {
        std::cerr << "Unable to open the file 'squares.txt' for writing" << std::endl;
        return 1;
    }


    for (int i = 1; i <= 10; ++i) {
        outputFile << i * i << std::endl;
    }


    outputFile.close();


    std::ifstream inputFile("squares.txt");


    if (!inputFile.is_open()) {
        std::cerr << "Unable to open the file 'squares.txt' for reading" << std::endl;
        return 1;
    }


    int square;
    while (inputFile >> square) {
        std::cout << square << std::endl;
    }


    inputFile.close();

    return 0;
}
