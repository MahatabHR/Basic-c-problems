#include <bits/stdc++.h>
using namespace std;
int main() {

    std::ifstream inputFile("input.txt");


    if (!inputFile.is_open()) {
        std::cerr << "Unable to open the file 'input.txt'" << std::endl;
        return 1;
    }


    std::string line;
    while (std::getline(inputFile, line)) {
        std::cout << line << std::endl;
    }


    inputFile.close();

    return 0;
}
