#include <bits/stdc++.h>
using namespace std;

int main()
{
    int a;
    cout << "Enter the first number:";
    cin >> a;
   if( (a % 2)== 0)
    {
    cout << "It is an even number.";
    }
    else
    {
        cout << "It is an odd number.";
    }
    cout << "\nThe result:" << a / 2 << endl;
    return 0;


}
