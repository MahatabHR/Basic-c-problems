#include <bits/stdc++.h>
using namespace std;

int main()
{
  int a,b;
  cout <<  "Enter the first number:";
  cin >> a;
  cout <<  "Enter the second number:";
  cin >> b;

  if(a>b)
  {
   cout << "First one is bigger than the second one.";
  }
  else if(b>a)
  {
      cout << "Second one is bigger then the first one.";
  }
  else if(a==b)
  {
      cout << "Both of them are equal.";
  }

  return 0;
}
