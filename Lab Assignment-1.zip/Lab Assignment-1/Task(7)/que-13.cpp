#include <bits/stdc++.h>
using namespace std;

int main()
{
  string city;
  string country;
  cout << "Enter the name of the city:" << city << endl;
  cin >> city;
  cout<< "Enter the name of the country:" << country << endl;
  cin >> country;
  string location = "city," + country;
  cout << "Location:" << location << endl;



}

