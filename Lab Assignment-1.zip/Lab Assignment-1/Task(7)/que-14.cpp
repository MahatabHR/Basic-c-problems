#include <bits/stdc++.h>
using namespace std;

int main()
{
    string booktitle = "Life After Death";
    string author = " \n                  By M.H.Rakib";
    string combined = booktitle + author;
    cout << combined << endl;
    return 0;
}

