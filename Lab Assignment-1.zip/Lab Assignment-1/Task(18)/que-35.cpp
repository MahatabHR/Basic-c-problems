
#include <bits/stdc++.h>
using namespace std;

int max(int a,int b)
{
    if(a>b)
    {
        return a;
    }
    return b;
}
int main()
{
    int a,b;
    cout << "Enter two numbers:\n";
    cin >> a >> b;
    cout << "Max of them:" << max(a,b) << endl;
    return 0;
}
