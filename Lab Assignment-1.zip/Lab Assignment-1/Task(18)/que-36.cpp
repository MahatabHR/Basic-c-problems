#include <bits/stdc++.h>
using namespace std;

double areaofCircle(double radius)
{
    return radius * radius * 3.14;
}
int main()
{
    double radius;
    cout << "Enter a radius:";
    cin >> radius;
    cout << "Area of circle :"<<areaofCircle(radius) << endl;
    return 0;
}
