#include<bits/stdc++.h>
using namespace std;

class Account{

public:
    int accountNumber;
    string accountHolder;
    double balance=0;

Account(int n, string h, double b)
    {
        accountNumber=n;
        accountHolder=h;
        balance=b;

        cout << "Account " << accountNumber << " created with balance " << balance << endl;
    }

Account(int n,string h)
    {
        accountNumber=n;
        accountHolder=h;
        cout << "Account " << accountNumber << " created with balance " << balance << endl;
    }

void deposit(int x)
    {
        balance += x;
        cout << "Deposit: " << x << ". New Balance: " << balance << endl;
    }

void withdraw(int y) {
    if (y <= balance)
        {
        balance -= y;
        cout << "Withdrawal: " << y << ". New Balance: " << balance << endl;
        }
        else
        {
            cout << "Insufficient funds. Withdrawal canceled." << endl;
        }
    }
};

int main() {
    Account account1(1001, "Alice");
    Account account2(1002, "Bob", 5000);
    account1.deposit(1500);
    account1.withdraw(800);

    return 0;
}
