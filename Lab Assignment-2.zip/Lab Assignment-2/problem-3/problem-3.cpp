#include<bits/stdc++.h>
using namespace std;
class Student{
public:
int rollNumber;
string name;
double marks=0;

Student(int r,string n){
rollNumber=r;
name=n;
cout<<"Student:"<< rollNumber << " Created with no marks" <<endl;
}


Student(int r,string n,double m){
rollNumber=r;
name=n;
marks=m;

cout <<"Student:"<< rollNumber << " created with marks:" << marks <<".";
}

void Grade(int x)
{
    x=marks;
    if(marks>=70 && marks<=80)
    {
    cout << "Grade:B"<<endl;
    }
}
};

int main()
{
    Student student1(101,"Tom");
    Student student2(102,"Lisa",75);

    student2.Grade(75);

}
