#include<bits/stdc++.h>
using namespace std;
class Car{
public:
    string model;
    string make;
    int rentalFee;

Car(string m,string M)
{
    model=m;
    make=M;
    cout<<"Car: "<< model <<" Created with no rental fee."<<endl;
}

Car(string m,string M,int f)
{
    model=m;
    make=M;
    rentalFee=f;
 cout <<"Car: "<< model << " Created with rental fee:" <<  rentalFee << "." ;
}
void Rentalfee(int x){
     x=rentalFee;
     cout << " Rental fee: " << x << endl;
}


};

int main()
{
    Car c1("Sedan","Toyota");
    Car c2("SUV","Ford",50);
    c2.Rentalfee(50);
}

