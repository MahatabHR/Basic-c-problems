#include<bits/stdc++.h>
using namespace std;
class Employee{
public:
    int employeeID;
    string name;
    int salary;

Employee(int ID,string n)
{
    employeeID=ID;
    name = n;
    cout<<"Employee:"<< employeeID << " Created with no salary" << endl;
}

Employee(int I,string n,int s)
{
    employeeID=I;
    name = n;
    salary=s;
    cout<<"Employee:" << employeeID << " Created with salary: " << salary << "." ;
}

void AnnualSalary(int x){
    x=salary * 12;
    cout << "Annual salary:" << x << endl;


}

};

int main()
{
    Employee a1 (001,"John");
    Employee a2 (002,"Jane",500);

    a2.AnnualSalary(5000);
}
