#include<bits/stdc++.h>
using namespace std;
class Book{
public:
string title;
string author;
int ISBN;
Book(string t,string a,int i)
{
title = t;
author = a;
ISBN =i;
cout  << "created" << endl;

}
~Book(){

cout << "Destroyed." << endl;


}
};

int main()
{
    Book P1("Object oriented","david",12345);
    Book P2("Introduction to c++","daniel",323332);
    return 0;

}
